


const fetchQuestion = () => {
    // Fetch a question from thehttps://the-trivia-api.com/api/questions?limit=5 API
  return   fetch('https://the-trivia-api.com/api/questions?limit=5')
  .then(response => response.json())
  .then(data => { 
    console.log(data    )  
    return data;
      
  })
  .catch(err => console.log(err))


}

export { fetchQuestion };


