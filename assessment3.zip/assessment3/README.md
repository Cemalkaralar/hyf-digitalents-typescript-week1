# Assessment 3



### Getting started

Execute your code with
```
npm run start
```

Run the tests with
```
npm run test
```